import React, { Component } from 'react';
import { StyleSheet, Switch, View, Text, Image, StatusBar } from 'react-native';

export default class App extends Component {
  state = {
    switchValue: false
  }

  render() {
    const { switchValue } = this.state;
    const backgroundColor = switchValue ? 'yellow' : 'black';
    const textColor = switchValue ? 'black' : 'white';
    const lightbulbImage = switchValue ? require('lightbulb.png') : require('lightbulb.png');

    return (
      <View style={[styles.container, { backgroundColor }]}>
        <StatusBar backgroundColor={backgroundColor} barStyle={switchValue ? "dark-content" : "light-content"} />
        <Image source={lightbulbImage} style={styles.imageStyle} />
        <Text style={[styles.textStyle, { color: textColor }]}>Switch Example</Text>
        <Switch
          style={{ marginBottom: 10 }}
          value={switchValue}
          onValueChange={(newValue) => this.setState({ switchValue: newValue })}
          thumbColor={switchValue ? 'yellow' : 'grey'}
          trackColor={{ false: 'white', true: 'gold' }}
        />
        <Text style={[styles.textStyle, { color: textColor }]}>{switchValue ? 'ON' : 'OFF'}</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textStyle: {
    margin: 24,
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  imageStyle: {
    width: 100,
    height: 100,
    marginBottom: 20,
  },
});